# Show Songs

Type a number (or a line of text) and it is drawn full-screen, scaled to fit the window. The display has no heading bar. Built for projecting hymn numbers: with the `l`/`c`/`k`/`s`/`b`/`e` keys it can show the same number in other languages' hymnals below the big one (English hymns 1-1348). No network needed once installed.

The app, home-page listing, and installed shortcut use a music-and-presentation-screen icon. The editable vector is `icons/icon.svg`; matching PNG icons cover Apple touch, 192px/512px installs, and maskable installs.

## Install (needs the files served over HTTPS once, so the browser can cache them)
- Host this folder on any static host (GitHub Pages, Netlify, Cloudflare Pages), open the URL, then:
  - Android / Chrome / Edge desktop: browser menu > Install app
  - iPhone / iPad: Safari > Share > Add to Home Screen
  - Mac Safari: File > Add to Dock
- After the first successful install/load, the complete bundled multilingual library is available offline. Later downloaded libraries are saved in IndexedDB and survive app cache updates. Background checks never block opening the app.

## Local use
Run `python3 -m http.server 8000` in this folder and open http://localhost:8000. Or just open index.html directly; it is fully self-contained.

## Shortcuts
Press `?` (or `/`) in number mode to see the list in-app.

| Key | Action |
| --- | --- |
| `0-9` | Type the number (number mode) |
| `←` / `→` | Hymn number -1 / +1 |
| `↑` / `↓` | Hymn number -37 / +37 |
| `Backspace` | Delete (number mode) / clear (text mode via Enter) |
| `Enter` | Clear (number mode) / new line (text mode) |
| `u` / `Ctrl/Cmd+Z` | Undo the previous content or number/text mode change |
| `Ctrl/Cmd+Shift+Z` / `Ctrl/Cmd+Y` | Redo (also available through the Redo button) |
| `-` / `+` | Smaller / bigger (with other languages showing, resizes them the opposite way) |
| `f` | Fill the window again |
| `Shift+F` | Full screen |
| `Esc` | Close the click menu first; with it closed, exit full screen |
| `w` / `Alt+W` | Toggle line wrapping |
| `h` | Cycle theme (system, black on white, white on black) — remembered |
| `m` | Show / hide the on-screen buttons (remembered) |
| `t` | Text mode (any characters); `Esc` or `Ctrl/Cmd+\` back to numbers |
| `Cmd/Ctrl+Enter` | Open hymn search from any mode; search titles and lyrics, use arrows to browse, Enter or click to select, Esc to cancel |
| `Space` | When number mode is empty, open hymn search. Otherwise, present the current hymn from stanza 1; Space exits to the unchanged number; `1`–`9` jumps to a stanza, `c` / `Shift+C` cycles choruses forward / backward, `s` / `Shift+S` cycles stanzas forward / backward from the current slide |
| `l` | All other languages for the number; always includes Chinese and both Spanish editions (`-` for missing matches) |
| `b` `k` `c` `s` `r` | Put Burmese / Korean / Chinese / Spanish 2nd / Russian on top, with English and the other languages below. Input and arrow navigation use the selected language’s own numbers (left/right ±1, up/down ±37). Switching languages converts the current number through its English reference; if none exists, the new number is blank. Present opens that language’s matching hymn text; unavailable lyrics show a message. Missing matches show `-`. Press the same key again for plain English; `e` selects the English layout. The selected main language is remembered. |
| `e` / `a` | Label the main number English + Korean; below, show Burmese and Chinese on the first row, Spanish 1st and Spanish 2nd on the second. The `e` view also shows Enjoyer Russian numbers on the same row as Spanish; `a` omits Russian (`-` if missing) |
| `E` (`Shift+e`) | Toggle alternate E/K view with Enjoyer Korean numbers on an additional row below; the main E/K number stays separate. Press `E` again to turn off; lowercase `e` switches to the regular view. Missing Korean links show `-`. |
| `Ctrl/Cmd+Delete` | Clear |
| `Ctrl/Cmd+C` | Copy the current value |
| `?` / `/` | This shortcut list (in text mode, `Ctrl/Cmd+/`) |
| `Ctrl/Cmd+\` | Switch number / text mode |

Undo and redo retain up to 500 content and number/text mode changes during the current session, including typing, deletion, arrow navigation, search selections, clears, and mode switches. New edits clear the redo history. Use the **Undo** and **Redo** buttons for mouse control; in text mode, plain `u` and `r` remain typed characters. In number mode, `r` selects Russian. When controls are visible, Esc hides them first. In full screen, the next Esc exits full screen without changing the current number, text, or presentation. Outside full screen, Esc in text mode returns to number mode. Fullscreen menu-first Escape handling uses the browser’s Keyboard Lock API when available and permitted; otherwise the browser may exit full screen immediately. Holding Esc remains the browser’s emergency exit gesture. Reloading starts a new history.

E/K number views start one `+` step larger by default, giving the main number more room above the language panel.

Click or tap any non-interactive area to toggle the on-screen controls. **Hide controls** or **Esc** also dismisses them; click a blank area again to bring them back. Buttons and other interactive elements keep their own actions. The magnifying-glass button opens hymn search. Their visibility is remembered, and touch screens show them by default. The scrollable toolbar sits at the bottom of the screen in number, text, and presentation modes and includes number entry, text/number editing, search, sizing, language views, and presentation actions (slide/stanza/chorus navigation, full song, bold, numbers, sidebar, fit, fullscreen, and exit). Presentation buttons share the number-mode controls’ font, uppercase labels, borders, and sizing. The presentation sidebar also lets you select individual stanzas and hymn versions.

## Notes
- The other-language table is embedded in the page (`XREF`, 1348 rows); it is the site's own cross-reference of English hymn numbers.
- Chinese numbers come from the consolidated mapping data: 705 main-book matches and 202 supplementary-book matches. Supplementary numbers use an `s` prefix (for example, English hymn 70 shows Chinese `s307`); they appear under Chinese in every language view. In Chinese main-number mode, arrow navigation continues from the highest main-book number into `s1`, `s2`, and onward; moving backward from `s1` returns to the main book. The ±37 arrows also cross this boundary. Type `s` (or `S`) followed by digits, paste `s123`, or use the number editor to enter a supplementary number directly. In Chinese number mode, `s` starts a fresh supplementary number instead of switching to Spanish; the Spanish toolbar button remains available. Chinese mode uses the text keyboard on mobile so the prefix can be entered. Chinese numbers of 9000 or higher appear only in All Languages (`l`) mode; E/K (`e`) and Chinese (`c`) modes show `-` for those codes.
- Spanish numbers use both columns in `sources/spanish hymns.pdf`, shown separately as **Spanish 2nd** (`S 2da`) and **Spanish 1st** (`S 1era`). The `s` shortcut and `e` view show both editions; the compact `e` labels are **S2** and **S1**. The second edition has 887 matches across 886 English hymns; the first edition has 481 matches. English hymn 912 lists both second-edition Spanish numbers 750 and 751, as in the source. Rows with unknown English numbers (`?`) are not mapped, and first-edition asterisks are treated as missing matches. Missing matches show `-` with the Spanish shortcut.
- Burmese numbers combine the PDF with explicit references from [Myanmar Hymns](https://myanmar-hymn-pwa.vercel.app/): 733 English hymns have mappings. English 170 includes 94 / 581, and 881 includes 470 / 629. PDF-only English 1160 → 569 is retained; English 353 → 208 remains corrected. All number views share these mappings. Source notes and mapping maintenance instructions are in [data/README.md](data/README.md).
- The display font (Big Shoulders Display) and utility font (IBM Plex Mono) come from Google Fonts; they are cached for offline after the first load, and the app falls back to system fonts if offline before that.

## Mapping and source data

[data/mappings.json](data/mappings.json) consolidates the active cross-reference tables and Enjoyer links. Edit it and run `python3 sync-mappings.py` to update the embedded standalone copy and cache version; `python3 sync-mappings.py --check` verifies that they match. See [data/README.md](data/README.md) for provenance, edition distinctions, Burmese corrections, and retained source PDFs. Historical comparison exports and the superseded English-only Songbase download have been removed. The complete `songbase_all.json` refresh snapshot and embedded lyrics remain available for offline use.

## Hymn presentation

In presentation mode, **J** moves down to the next slide and **K** moves up to the previous slide, matching the arrow keys. **H** jumps to the first slide (also **Home**); **Shift+H** jumps to the last slide (also **End**).

Type a hymn number and press **Space**, or tap **Present**, to show its lyrics one stanza or chorus at a time. A left sidebar keeps the English hymn number and your selected language numbers visible, including the current `e` / `a`, alternate E/K, or All Languages view. Press **Tab** to show or hide the entire left sidebar; lyrics refit to the available width. Press **N** to show or hide only the hymn and language number list; this choice is remembered across hymns and app restarts. In `a` mode, number labels appear inline as compact characters (`E/K`, `B`, `C`, `S1`, `S2`) before their numbers, with large numbers matching the `E/K` label’s font size. Lyrics automatically fit the remaining space and follow the selected theme. Press **-** to decrease the presentation font size or **=** (also **+**) to increase it up to Fill size (further enlargement is disabled once the lyrics fill the available space); the chosen scale carries across stanza changes. Opening a song, switching its language/version, or toggling full-song view resets sizing to Fill. Press **0** or **F** to reset the size and enlarge the lyrics until they fill the available width or height, with no fixed font-size cap. **Shift+F** toggles fullscreen in presentation mode. Presentation controls, the title, and the clickable slide list sit in the left sidebar alongside the hymn numbers, leaving the full content height for lyrics. Exit sits above the song name, stays visible while scrolling the sidebar, and wraps to fit narrow screens. The slide list wraps and scrolls vertically and lists every slide in order, including repeated choruses. Click or tap a stanza or chorus to go directly to it; the current slide is highlighted. Slide buttons use just the stanza number or `c` for a chorus; navigation buttons use arrows only. Hovering a slide button previews its lyrics. Press **?** or **/** during presentation for its shortcut page; any plain key closes help without changing the slide. Number and text modes have their own shortcut pages. Press **Shift+L** to cycle directly through available languages without opening the popup, wrapping at the end and keeping full-song view if active. Press **L** to toggle the available-languages popup, or click **Languages** to open it. The popup shows a list of all linked language versions of the current song. Use **arrow keys** or **J/K** to browse language versions (wrapping at either end), then **Enter** to select. The current version receives focus when the popup opens. Select a version to present its lyrics; **Esc** or the close button dismisses the popup. Songs without linked translations show only their own version. Press **B** to toggle bold lyrics in either slide or full-song view; the choice is remembered across hymns and app restarts. Press **Enter** to show the entire song, with repeated identical choruses shown only at their first occurrence by default. Press **R** in presentation mode or click **Repeat chorus** to show or hide repeated choruses in full-song view; the choice is remembered across songs and app restarts. Full-song view uses smaller, muted stanza numbers and “C” labels beside the first lyric line, separated by a two-character gap; subsequent lines align with the lyrics, indented from the label. Full-song view fills the available space by choosing the largest fitting font across up to four height-constrained, balanced columns, keeping each entire stanza (including all its paragraphs) or chorus together in one column. The fitting calculation shrinks text as needed to fit these whole sections; repeated choruses follow complete stanzas. It refits when the window, sidebar, toolbar, or fonts change; press **Enter** again to return to the previous slide. Selecting a stanza or chorus also returns to slide view. Press **1–9** to jump directly to a stanza. **C** cycles forward through choruses; **Shift+C** cycles backward. **S** cycles forward through stanzas from the current slide; **Shift+S** cycles backward. Both cycles wrap around. Previous / Next buttons and arrow keys also navigate slides. **Space** is the only keyboard shortcut that exits presentation; the **Exit** button also works by touch or click. Returning preserves the number and language selections; the first digit entered afterward starts a new hymn number instead of appending to the old one. A single chorus is repeated after each stanza. By default, chord brackets, `#` metadata, and numeric Capo instructions are hidden. Press **G** or click **Guitar** to toggle chords above the lyrics and show the song’s numeric capo instruction in the left sidebar (or “Capo not specified” when absent). Guitar mode works in slide and full-song views, preserves the current slide, refits the lyrics, and is remembered across songs and app restarts. Multi-paragraph stanzas use labels such as `1.1`, `1.2`, and `1.3`; single-paragraph stanzas keep their usual number. Number shortcuts jump to the first paragraph of a stanza.

The full embedded Songbase snapshot supplies all 1,348 English hymn numbers using the `english_hymnal` book’s **song ID → hymn number** mapping, including hymn 745, which was missing from the earlier English-only import. Songs with `###` headings split into separate lyrics versions, selectable in the presentation header or cycled with **T**. Only the selected version appears in the lyrics, full-song view, stanza/chorus sidebar, and guitar/capo display. Separate song entries (such as hymn 1193) remain selectable as versions too. Missing hymns show a message instead of opening an empty presentation. The library is embedded in `index.html`, so it works offline and from `file://` without fetching the source JSON. The earlier `songbase_english.json` is retained as the original import source. Loading a newer saved or published library rebuilds the English hymnal mapping and lyrics, so additions and corrections work in number mode too.

### Hymn text search

In empty number mode, press **Space** to search titles and lyrics across all 9,362 imported songs in 19 language categories. **Cmd+Enter** (Mac) / **Ctrl+Enter** opens search from number, text, presentation, or shortcut views. Search supports non-Latin scripts and ignores chords, accents, apostrophes, case, and punctuation; multiple words can match anywhere in the title or lyrics. Exact English hymn numbers and title matches rank first. Results include language and songbook numbers where available. Up to 40 results are shown; type more to narrow the list. Use arrows and Enter, or click a result, to display its hymn number. Press **Space** while a result is focused to present it immediately, including songs in the English hymnal. Spaces in the search field still enter search text. Selecting an English hymnal result returns to number mode; **Space** then presents it. Other songs open directly in presentation mode, and exiting returns to the previous display. Songs outside the English hymnal (1–1348) show **Songbase** on one line and their Songbase ID on the next; both lines fit the sidebar without wrapping, including after resizing. **Esc** or the close button cancels without changing the previous text, hymn, slide, or language selections. Search works offline and from `file://`; the full Songbase snapshot is embedded in the page.

### Full Songbase source snapshot

Run `python3 songbasescraper.py --embed` to download and validate the complete available Songbase API library, save `songbase_all.json`, update the embedded offline library, and bump the service-worker cache version. The script uses Python’s standard library and resolves paths relative to its own folder. Without `--embed`, it updates the archive and cache version only. Invalid downloads leave existing files intact; unchanged songs/books do not produce updates just because the API fetch timestamp changed. The snapshot saved on 2026-11-11 contains 9,362 songs across 19 languages, plus book mappings and language links. The full snapshot is also embedded in `index.html` for multilingual search and presentation.

### Offline libraries and background updates

All bundled songs, lyrics, chords, songbook mappings, and language links work offline after installation. On every page load, return from the background, or reconnection, the app opens immediately with its embedded library, loads any newer saved library from IndexedDB, and checks `./songbase_all.json` in the background. Complete validated updates rebuild search and hymn mappings, then are persisted for later offline use; the current presentation is preserved. Failed downloads, invalid data, older snapshots, or unavailable storage never erase the usable library. Search shows the library count and update/offline status. The saved `bigtext-songbase` database is independent of service-worker cache versions. Browser storage clearing removes downloaded updates; the embedded library remains the fallback. A copied app folder and `file://` still work without a network request.

Songbase’s API does not allow cross-origin browser reads, so live scraping happens in the repository’s `Update Songbase library` GitHub Actions workflow every six hours (00:17, 06:17, 12:17, and 18:17 UTC; GitHub schedules may be delayed), or manually from the Actions tab. It runs `songbasescraper.py --embed`, commits changed data, and requests a Pages rebuild. Each app refresh/reopen checks the last published snapshot; it does not start a new upstream scrape. To run the job immediately, use **Actions → Update Songbase library → Run workflow** after this workflow is pushed to the default branch. Actions must be enabled and allow the configured contents/Pages write permissions. No npm packages or third-party proxy are used.

### Saved preferences

Language-number views (including selected languages and both E/K variants), wrapping, number/text mode, bold lyrics, guitar chords, repeated choruses, full-song view, and sidebar/number-list visibility are remembered in `localStorage` under `bigtext-settings`. Theme and on-screen-control visibility keep their existing `bigtext-theme` and `bigtext-pad` keys. The last full-song/slide view is used when opening another hymn. Sizing still starts at Fill; displayed text, the current hymn/slide, and undo/redo history remain session-only. If browser storage is blocked or saved settings are invalid, the app uses safe defaults.

### Burmese hymn text

735 Burmese hymns from the Myanmar Hymns website are embedded separately in `index.html` (`burmese-data`), imported on 2026-11-11 from its published SQLite database. Search by Burmese title/text or `Burmese Hymns` plus a number, then select a result to present its lyrics. From an English hymn, the presentation language selector also offers its linked Burmese hymn(s). The import preserves verse/chorus text and stays available offline and under `file://`; loading a newer Songbase library retains it. The separate Myanmar young people’s/new-song collection is not included. Burmese 700 references English 1351, outside the current number view, but remains searchable. See [the website comparison](burmese_website_comparison.md) and [CSV](burmese_website_comparison.csv) for the comparison before this update.

In B/K/C/S/R number views, Present uses the selected hymnal’s exact number. Burmese, Korean, and Chinese use bundled book numbers. Spanish 2nd resolves its English cross-reference to linked Spanish text, because the bundled Spanish book uses different numbering; the current library has no Russian lyrics, so Russian Present reports that lyrics are unavailable. Numbers without an English cross-reference still navigate and can present when their book contains text; other-language references show `-`.

Presentation wrapping prefers punctuation boundaries (commas, semicolons, colons, and sentence endings), preserving existing lyric line breaks. Clauses that exceed the available width still wrap at words. In full-song view, wrapped rows reserve their full height so the following lyric line stays below them. This applies to stanza, full-song, and guitar views.

The presentation sidebar has a compact × exit icon; its tooltip shows the Space shortcut.

Full-song fitting checks lyric phrases and stanza boundaries for overflow and overlap, rechecks the final column layout, and refits when its available space or fullscreen state changes.


## Usage counts

This app reports fixed app/event labels to GoatCounter for visible page opens, opens in standalone/minimal-ui mode (including iOS home-screen mode), and browser-supported `appinstalled` events. Reloads count as opens; returning to an already open app does not. Installed opens are a subset of all opens. Install detection is incomplete, especially on iOS; downloads and uninstall totals are not measured.

No entered content, searches, Scripture, lyrics, full URLs, referrers, cookies, or persistent visitor IDs are sent by this code. Like any external request, the analytics service receives the IP address and browser headers. Do Not Track and Global Privacy Control disable reporting. Localhost, file hosting, and automated browsers do not report. Offline/failed events retry in the same tab, with a limit of 100 events retained for seven days in sessionStorage; closing the tab can lose pending counts. Reports use delivery time, so delayed events appear on the day they are sent. Blockers and interrupted requests can cause missing or duplicate counts. Analytics failures never block app functionality.

Maintainers can view totals at https://atlantachristianstudents.goatcounter.com. In its Events view, filter by `apps/show-songs/open`, `apps/show-songs/installed-open`, or `apps/show-songs/install`. The self-contained `acswebapps-usage` script in `index.html` must stay in sync with the other apps.

The bottom of the **?** shortcut help says “Show Songs is part of the ACS Web Apps project” as plain text. On mobile screens (up to 767px wide), a separate **Back to ACS Web Apps** button links to the app directory.

The display has no floating help button. Use the existing **?** / **/** keyboard shortcuts for help; the project information and mobile back link remain available there.

Browser pinch-to-zoom is disabled. Single-finger scrolling, input editing, and the app’s own controls remain available.

Press **Cmd+U** (Mac) or **Ctrl+U** (Windows/Linux) from any mode to check for updates. The shortcut opens the help panel to show update status; there is no update button. Save your work first; the app checks for a newer version, downloads and activates it, and restarts when needed. Status messages cover offline use, failures, and an already-current app. Downloaded content in IndexedDB is preserved.

Full-song fitting checks that opening lyric rows remain inside the visible columns and resets the lyric scroll position after fitting, including after resizing or toggling chords.
